# Mirror of Standfords's FRILibrary

A custom version of [Fast Research Interface Library](http://cs.stanford.edu/people/tkr/fri/html/)
